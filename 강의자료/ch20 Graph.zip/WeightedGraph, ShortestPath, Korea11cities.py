# Application of Graph with DFS, BFS, Dijkstra(Shotest Path Finding)

from MyGraph import *
 

if __name__ == "__main__":
    WG = fgetWeightedGraph("KR_11_cities.txt")
    printWeightedGraph(WG)
    
    start_nm = "GJ" # 
    end_nm = "SC" # 
    print("Trying ShortestPath_Dijkstra : ({} -> {})".format(start_nm, end_nm))
    path_Dijkstra, path_cost = Dijkstra(WG, start_nm, end_nm)
    print("Found shortestPath_Dijkstra ({} -> {}): {}, total_path_cost ={}".format(start_nm, end_nm, path_Dijkstra, path_cost))

    start_nm = "SC" 
    end_nm = "GJ"  
    print("Trying ShortestPath_Dijkstra : ({} -> {})".format(start_nm, end_nm))
    path_Dijkstra, path_cost = Dijkstra(WG, start_nm, end_nm)
    print("Found shortestPath_Dijkstra ({} -> {}): {}, total_path_cost ={}".format(start_nm, end_nm, path_Dijkstra, path_cost))
    
