# SLAM_Sim_Env.py

import math, pygame
import numpy as np
import Colors

neighbor_range = 20
class Env_Point():
    def __init__(self):
        self.x = 0
        self.y = 0
        self.cluster_id = -1 # initially not belong to any cluster
        self.value = 0 # value of this point

class Cluster():
    def __init__(self):
        self.id = -1
        self.points = [] # points (x, y) included in this cluster
        self.shape = "not_defined"
    def add_point(self, point):
        self.points.append(point)
            
class SLAM_Sim_Environment():
    def __init__(self, MapDimensions, floor_map_fname):
        pygame.init()   
        self.obj_points = []
        self.clusters = []
        self.num_clustered_points = 0
        self.floor_map = pygame.image.load(floor_map_fname)
        self.mapW, self.mapH = MapDimensions
        self.MapWindowTitle = "SLAM_Sim"
        pygame.display.set_caption(self.MapWindowTitle)
        self.map = pygame.display.set_mode((self.mapW, self.mapH))
        self.obj_map = pygame.display.set_mode((self.mapW, self.mapH))
        self.obj_map.fill(Colors.Color_White)
        #self.map.blit(self.obj_map, (0, 0))
        # initialize env_points 2-dimensional list
        self.env_points = [] # used as two-dimentional array of env_point
        self.num_sensed_points = 0
        for y in range(self.mapH):
            row = []
            for x in range(self.mapW):
                env_point = Env_Point()
                env_point.x = x
                env_point.y = y
                env_point.cluster_id = -1
                env_point.value = 0
                row.append(env_point)
            self.env_points.append(row)

    def update_obj_map(self, points, lidar):
        #print("SLAM_Sim_Env::update_obj_map() - lidar.num_objects = {}".format(lidar.num_objects))
        if len(points) <= 0:
            print("Trying to store_data with empty data")
            return
        for point in points:
            # obj : (distance, angle, (lidar_pos x, y), obj_pos(x, y))
            pos_x, pos_y = point
            if isinstance(pos_x, int) and isinstance(pos_y, int):
                #obj_pos = (pos_x, pos_y)# for test only
                #self.obj_map.set_at(point, Colors.Color_Blue) #Colors.Color_Blue
                if self.env_points[pos_y][pos_x].value != 255:
                    self.env_points[pos_y][pos_x].value = 255 # set as occupied by object
                    self.num_sensed_points += 1
                    pygame.draw.circle(self.obj_map, Colors.Color_Blue, point, 2, 0)
            else:
                print("update_obj_map():: Trying to update_obj_map with non-int coordinates({}, {})".format(pos_x, pos_y))

    def update_clusters(self):
        y_max = len(self.env_points)
        x_max = len(self.env_points[0])
        self.num_clustered_points = 0
        for y in range(y_max):
            for x in range(x_max):
                if self.env_points[y][x].value == 0:
                    continue
                if self.env_points[y][x].cluster_id == -1:
                    neighbors = []
                    x_low = 0 if (x - neighbor_range) < 0 else x - neighbor_range
                    x_high = x_max if (x + neighbor_range) > x_max else x + neighbor_range
                    y_low = 0 if (y - neighbor_range) < 0 else y - neighbor_range
                    y_high = y_max if (y + neighbor_range) > y_max else y + neighbor_range
                    for y_n in range(y_low, y_high):
                        for x_n in range(x_low, x_high):
                            if y == y_n and x == x_n:
                                continue
                            if self.env_points[y_n][x_n].value == 0:
                                continue
                            neighbors.append((x_n, y_n))
                    if len(neighbors) != 0:
                        dist_min = neighbor_range * 1.5
                        neighbor_min_dist = None
                        cluster_id_min = -1
                        for nh in neighbors:
                            (x_n, y_n) = nh
                            dist = np.sqrt((x - x_n)**2 + (y - y_n)**2)
                            nh_cid = self.env_points[y_n][x_n].cluster_id
                            if (dist < dist_min) and  nh_cid != -1:
                                cluster_id_min = nh_cid
                                neighbor_min_dist = nh
                        if neighbor_min_dist != None: 
                            self.clusters[cluster_id_min].points.append((x, y))
                            self.env_points[y][x].cluster_id = cluster_id_min
                        else:
                            print("update_clusters :: configuring a new cluster by adding ({}, {})".format(x, y))
                            cluster = Cluster()
                            cluster.id = len(self.clusters)
                            cluster.points = [(x, y)]
                            cluster.shape = "non_defined"
                            self.clusters.append(cluster)
                            self.env_points[y][x].cluster_id = cluster.id  
                    else: # if len(neighbors) == 0: # no nearby neighbor(s)
                        print("update_clusters :: configuring a new cluster by adding ({}, {})".format(x, y))
                        cluster = Cluster()
                        cluster.id = len(self.clusters)
                        cluster.points = [(x, y)]
                        cluster.shape = "non_defined"
                        self.clusters.append(cluster)
                        self.env_points[y][x].cluster_id = cluster.id       
                    self.num_clustered_points += 1

        # expand cluster with its neighbor points
        num_clusters = len(self.clusters)
        self.num_clustered_points = 0
        for cluster in self.clusters:
            num_points_in_cluster = len(cluster.points)
            self.num_clustered_points += num_points_in_cluster
            for point in cluster.points:
                my_cid = cluster.id
                points = []
                (x, y) = point
                x_low = 0 if (x - neighbor_range) < 0 else x - neighbor_range
                x_high = x_max if (x + neighbor_range) > x_max else x + neighbor_range
                y_low = 0 if (y - neighbor_range) < 0 else y - neighbor_range
                y_high = y_max if (y + neighbor_range) > y_max else y + neighbor_range
                for y_n in range(y_low, y_high):
                    for x_n in range(x_low, x_high):
                        if y == y_n and x == x_n:
                            continue
                        if  self.env_points[y_n][x_n].cluster_id == -1:
                            points.append((x_n, y_n))
                            self.env_points[y_n][x_n].cluster_id = my_cid
                        elif self.env_points[y_n][x_n].value == my_cid:
                            continue
                        elif self.env_points[y_n][x_n].value == 0:
                            continue
                        else: # neighbor cluster can be merged
                            pass # to be updated
        # merge clusters
        
    def draw_clusters(self, feature_extract):
        num_clusters = len(self.clusters)
        # draw lines from clusters
        for cluster in self.clusters:
            num_points_in_cluster = len(cluster.points)
            result_seg_dect = feature_extract.seed_segment_detection_from_clusters(cluster.points)
            if result_seg_dect == None:
                continue
            seed_segment_objs = result_seg_dect[0] # self.lidar.sensed_objects[i:j]
            predicted_points_to_draw = result_seg_dect[1] #predicted_points_to_draw
            index_range = result_seg_dect[2] # (i, j)
            result_seg_grow = feature_extract.seed_segment_growing_from_clusters(cluster.points, index_range)
            # results format : [self.lidar.sensed_objects[pb:pf], self.two_points, (self.lidar.sensed_objects[pb+1],
            #                    self.lidar.sensed_objects[pf-1]), pf, line_eq, (m, b)]
                
            if result_seg_grow == None:
                continue

            line_eq = result_seg_grow[4]
            m, c = result_seg_grow[5]
            line_segs = result_seg_grow[0]
            outer_most = result_seg_grow[2]
            break_point_idx = result_seg_grow[3]
            end_points_0 = feature_extract.projection_p2line(outer_most[0], m, c)
            end_points_1 = feature_extract.projection_p2line(outer_most[1], m, c)
            color = Colors.random_color()
            pygame.draw.line(self.obj_map, Colors.Color_Red, outer_most[0], outer_most[1], 4)
            self.map.blit(self.obj_map, (0, 0))
            pygame.display.update() 



