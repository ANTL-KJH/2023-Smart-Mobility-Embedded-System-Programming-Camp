# Colors.py

import random

Color_Black = (0, 0, 0)
Color_Grey = (70, 70, 70)
Color_Blue = (0, 0, 255)
Color_Green = (0, 255, 0)
Color_Red = (255, 0, 0)
Color_White = (255, 255, 255)

def random_color():
    levels = range(32, 256, 32)
    return tuple(random.choice(levels) for _ in range(3))
