# SLAM_Sim_FeatureExtraction.py

import math
import numpy as np
from fractions import Fraction
from scipy.linalg import lstsq

class FeatureExtraction():
    def __init__(self, env, lidar, max_cluster):
        self.EPSILON = 10
        self.DELTA = 10
        self.SNUM = 6
        self.PMIN = 5
        self.GMAX = 20
        self.LMIN = 5 # minimum length of a line segment
        self.seed_segments = []
        self.line_segments = []
        self.env = env
        self.lidar = lidar
        self.line_params = None
        self.num_points = 0 # the number of LiDAR points contained in the line segment


    def dist_p2p(self, p1, p2):
        if (isinstance(p1[0], int) or isinstance(p1[0], float)) and (isinstance(p1[1], int) or isinstance(p1[1], float)) and\
             (isinstance(p2[0], int) or isinstance(p2[0], float)) and (isinstance(p2[1], int) or isinstance(p2[1], float)):
            sq_dx = (p1[0] - p2[0]) ** 2
            sq_dy = (p1[1] - p2[1]) ** 2
            return math.sqrt(sq_dx + sq_dy)
        else:
            print("Warning in dist_p2p() :: p1 = {}, p2 = {}".format(p1, p2))
            return 0.0
        
    def dist_p2line(self, line_eq, p):
        #print("dist_p2line:: line_eq = {}, p = {}".format(line_eq, p))
        A, B, C = line_eq
        if (isinstance(p[0], int) or isinstance(p[0], float)) and (isinstance(p[1], int) or isinstance(p[1], float)) :
            dist = abs(A*p[0] + B*p[1] + C) / math.sqrt(A**2+B**2)
            return dist
        else:
            print("Error in dist_p2line():: p[0] = {}, p[1] = {}".format(p[0], p[1]))
            return None

    def line_2points(self, m, b):
        x = 5
        y = m * x + b
        x2 = 2000
        y2 = m * x2 + b
        return [(x, y), (x2, y2)]
    
    def lineForm_G2SI(self, A, B, C): # general form of slope-intercept
        m = -A / B
        b = -C / B
        return m, b
    
    def lineForm_SI2G(self, m, b):
        A, B, C = -m, 1, -b
        if A < 0:
            A, B, C = -A, -B, -C
        den_a = Fraction(A).limit_denominator(1000).as_integer_ratio()[1]
        den_c = Fraction(C).limit_denominator(1000).as_integer_ratio()[1]
        gcd = np.gcd(den_a, den_c)
        lcm = den_a * den_c / gcd

        A = A * lcm
        B = B * lcm
        C = C * lcm
        return A, B, C

    def line_intersect_general(self, line_eq1, line_eq2):
        a1, b1, c1 = line_eq1
        a2, b2, c2 = line_eq2
        x = (c1*b2 - b1*c2) / (b1*a2 - a1*b2)
        y = (a1*c2 - a2*c1) / (b1*a2 - a1*b2)
        return x, y

    def points_2line(self, p1, p2):
        m, b = 0, 0
        if p2[0] == p1[0]:
            pass
        elif isinstance(p1[0], int) and isinstance(p1[1], int) and\
             isinstance(p2[0], int) and isinstance(p2[1], int):
            m = (p2[1] - p1[1]) / (p2[0] - p1[0])
            b = p2[1] - m*p2[0]
        else:
            print("Warning in points_2line() :: p1 = {}, p2 = {}".format(p1, p2))
        return m, b

    def projection_p2line(self, p, m, b):
        x, y = p
        m2 = -1 / m
        c2 = y - m2 * x
        intersection_x = -(b - c2) / (m - m2)
        intersection_y = m2 * intersection_x + c2
        return intersection_x, intersection_y

    def lstsq_fit(self, points):
        #print("lstsq_fit({})..".format(len(points)), end='') # for debugging only
        x_data = []
        y_data = []
        for p in points:
            if (isinstance(p[0], int) or isinstance(p[0], float))\
               and (isinstance(p[1], int) or isinstance(p[1], float)):
                x_data.append(p[0])
                y_data.append(p[1])
        x = np.array(x_data)
        X = np.vstack([x, np.ones(len(x))]).T
        y = np.array(y_data)
        p, resiuals, rank, s = lstsq(X, y)
        #print("lstsq(X, y, rcond=None) => p={}, residuals={}, rank={}, s={}".format(p, resiuals, rank, s))
        m, b = p[0], p[1]
        #print("np_lstsq_fit() returns m = {}, b = {}".format(m, b))
        
        return m, b
    
    def predictPoint(self, line_params, sensed_point, lidar_pos=(0, 0)):
        m, b = self.points_2line(lidar_pos, sensed_point)
        line_eq1 = self.lineForm_SI2G(m, b)
        pred_x, pred_y = self.line_intersect_general(line_eq1, line_params)
        return (pred_x, pred_y)

 #----------------------- 
    def seed_segment_detection_from_clusters(self, cluster_points):
        #print("SSDC..", end='') # for debugging only
        flag = True
        num_points = len(cluster_points)
        if num_points < self.SNUM:
            return None # cluster segment is too short 
        seed_segments = []
        for i in range(num_points):
            predicted_points_to_draw = []
            j = min(i + self.SNUM, len(cluster_points))
            #m, b = self.odr_fit(lidar.sensed_points[i:j])
            #m, b = self.linear_regression_fit(lidar.sensed_points[i:j])
            m, b = self.lstsq_fit(cluster_points[i:j])
            params = self.lineForm_SI2G(m, b)
            for k in range(i, j):
                predicted_point = self.predictPoint(params, cluster_points[k])
                if not (isinstance(predicted_point[0], int) or isinstance(predicted_point[0], float)) and\
                   not (isinstance(predicted_point[1], int) or isinstance(predicted_point[1], float)):
                    print("Warning in seed_segment_detection:: predicted_point({}, {})".format(predicted_point[0], predicted_point[1]))
                predicted_points_to_draw.append(predicted_point)
                pk = cluster_points[k]
                if not isinstance(pk[0], int) or not isinstance(pk[1], int):
                    print("Warning in seed_segment_detection:: pk({}, {})".format(pk[0], pk[1]))
                d1 = self.dist_p2p(predicted_point,pk)

                if d1 > self.DELTA:
                    flag = False
                    break
                d2 = self.dist_p2line(params, predicted_point)
                if d2 > self.EPSILON:
                    flag = False
                    break
            if flag:
                self.line_params = params
                result = [cluster_points[i:j], predicted_points_to_draw, (i, j)]
                return result
        return None


 #-----------------------       
    def seed_segment_growing_from_clusters(self, cluster_points, index_range):
        #print("SSG..", end='') # for debugging only
        num_points = len(cluster_points)
        if num_points < self.SNUM:
            return None # cluster segment is too short 
        
        line_eq = self.line_params
        pb, pf = index_range
        pf = min(pf, len(cluster_points)-1)
        while True:
            pf_point = cluster_points[pf]
            if not isinstance(pf_point[0], int) or not isinstance(pf_point[1], int):
                print("Warning in seed_segment_growing:: calling dist_p2line with pf_point({}, {})".format(pf_point[0], pf_point[1]))
            if self.dist_p2line(line_eq, pf_point) >= self.EPSILON:
                break
            if pf >= num_points - 1:
                break
            else:
                #m, b = self.odr_fit(self.lidar.sensed_points[pb:pf])
                #m, b = self.linear_regression_fit(self.lidar.sensed_points[pb:pf])
                m, b = self.lstsq_fit(self.lidar.sensed_points[pb:pf])
                line_eq = self.lineForm_SI2G(m, b)

                point = cluster_points[pf]
            pf = pf + 1
            next_point = cluster_points[pf]
            if not isinstance(next_point[0], int) or not isinstance(next_point[1], int):
                print("Warning in seed_segment_growing:: next_point({}, {})".format(next_point[0], next_point[1]))
            if self.dist_p2p(point, next_point) > self.GMAX:
                break
        pf = pf - 1
        while True:
            pb_point = cluster_points[pb]
            if not isinstance(pb_point[0], int) or not isinstance(pb_point[1], int):
                print("Warning in seed_segment_growing():: calling dist_p2line with pb_point({}, {})".format(pb_point[0], pb_point[1]))
            if self.dist_p2line(line_eq, pb_point) >= self.EPSILON:
                break
            if pb <= 0:
                break
            else:
                #m, b = self.odr_fit(self.lidar.sensed_points[pb:pf])
                #m, b = self.linear_regression_fit(self.lidar.sensed_points[pb:pf])
                m, b = self.lstsq_fit(self.lidar.sensed_points[pb:pf])
                line_eq = self.lineForm_SI2G(m, b)
                point = self.lidar.sensed_points[pb]
            pb = pb - 1
            next_point = self.lidar.sensed_points[pb]
            if not isinstance(next_point[0], int) or not isinstance(next_point[1], int):
                print("Warning in seed_segment_growing:: calling dist_p2line with next_point({}, {})".format(next_point[0], next_point[1]))
            if self.dist_p2p(point, next_point) > self.GMAX:
                break
        pb = pb + 1

        dist_line_seg = self.dist_p2p(cluster_points[pb], cluster_points[pf]) # distance of line segment
        pts_line_seg = len(cluster_points[pb:pf]) # number of points in line segment
        if (dist_line_seg >= self.LMIN) and (pts_line_seg >= self.PMIN):
            self.line_params = line_eq
            m, b = self.lineForm_G2SI(line_eq[0], line_eq[1], line_eq[2])
            self.two_points = self.line_2points(m, b)
            self.line_segments.append((cluster_points[pb+1], cluster_points[pf-1]))
            result = [cluster_points[pb:pf], self.two_points,\
                      (cluster_points[pb], cluster_points[pf]), pf, line_eq, (m, b)]
            return result
        else:
            return None        

                                   
