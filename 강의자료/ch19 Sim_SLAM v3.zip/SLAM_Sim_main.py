# SLAM_Sim main.py

import SLAM_Sim_Env, SLAM_Sim_LiDAR, SLAM_Sim_FeatureExtraction, Colors
import pygame, math, time

environment = SLAM_Sim_Env.SLAM_Sim_Environment((1200, 750), "floor_map.png")
lidar = SLAM_Sim_LiDAR.LiDAR(200, environment, uncertainty=(0.5, 0.01))
feature_extract = SLAM_Sim_FeatureExtraction.FeatureExtraction(environment, lidar, max_cluster=500)
pygame.mouse.set_cursor(*pygame.cursors.diamond)

MAX_ROUND = 350
running = True
round = 0
while round < MAX_ROUND:
    print("Round {:5d}, num_sensed_points {:5d}, num_clusters {:3d}, num_clustered_points {:4d}"\
          .format(round, environment.num_sensed_points, len(environment.clusters), environment.num_clustered_points))
    sensor_on = False
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            break
        if pygame.mouse.get_focused() and pygame.mouse.get_pressed() == (1, 0, 0):
            sensor_on = True
            mouse_pos = pygame.mouse.get_pos()
            lidar.lidar_pos = mouse_pos # set the position of lidar
            sensed_points = lidar.sense_obstacles()
            environment.update_obj_map(sensed_points, lidar)
        elif not pygame.mouse.get_focused() and pygame.mouse.get_pressed() != (1, 0, 0):
            sensor_on = False
    # Feature extraction from the collected/sensed data
    environment.update_clusters()
    environment.draw_clusters(feature_extract)

    if running == False:
        break
    environment.map.blit(environment.obj_map, (0, 0))
    pygame.display.update()
    #time.sleep(0.1)
    round += 1

input("\nInut any key to Quit SLAM simulation")
pygame.quit()
