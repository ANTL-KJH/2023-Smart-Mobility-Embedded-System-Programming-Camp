# SLAM_Sim_LiDAR.py

import pygame, math
import numpy as np
import Colors

class LiDAR:
    def __init__(self, laser_range, environment, uncertainty):
        self.lidar_range = laser_range
        self.speed = 4 # rounds per second
        self.sigma = np.array([uncertainty[0], uncertainty[1]])
        self.lidar_pos = (0, 0)
        self.floor_map = environment.floor_map
        self.winW, self.winH = pygame.display.get_surface().get_size()
        self.sensed_objects = []
        self.sensed_points = []
        self.num_objects = 0
        
    def add_uncertainty(self, distance, angle, sigma):
        mean = np.array([distance, angle])
        cov = np.diag(sigma ** 2)
        dist, angle = np.random.multivariate_normal(mean, cov)
        distance = max(dist, 0)
        angle = max(angle, 0)
        return distance, angle

    def distance(self, obj_pos):
        sq_dx = (obj_pos[0] - self.lidar_pos[0])**2
        sq_dy = (obj_pos[1] - self.lidar_pos[1])**2
        dist = math.sqrt(sq_dx + sq_dy)
        return dist
    
    def sense_obstacles(self):
        sensed_points = []
        x1, y1 = self.lidar_pos[0], self.lidar_pos[1]
        for angle in np.linspace(0, 2*math.pi, 60, False):
            x2, y2 = (x1 + self.lidar_range*math.cos(angle), y1 - self.lidar_range*math.sin(angle))
            for i in range(0, 100):
                u = i / 100
                x = int(x2*u + x1*(1-u))
                y = int(y2*u + y1*(1-u))
                if not (0<x<self.winW and 0<y<self.winH):
                    continue
                color = self.floor_map.get_at((x, y))
                if color == Colors.Color_Black:
                    distance = self.distance((x, y))
                    dist, angle = self.add_uncertainty(distance, angle, self.sigma)
                    sensed_obj = (dist, angle, self.lidar_pos, (x, y))
                    # (distance, angle, (lidar_pos x, y), obj_pos(x, y))
                    sensed_points.append(sensed_obj[3])
                    self.sensed_points.append(sensed_obj[3])
                    self.sensed_objects.append(sensed_obj)
                    self.num_objects += 1
                    break
        return sensed_points
