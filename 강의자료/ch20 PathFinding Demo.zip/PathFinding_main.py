# Path Finding with PathFinding Module on given Floor Map

import pygame, Colors, time, sys
from pathfinding.core.grid import Grid
from pathfinding.finder.a_star import AStarFinder
from pathfinding.core.diagonal_movement import DiagonalMovement

class PathFinder():
    def __init__(self, floor_map_fname, grid_size):
        self.floor_map = pygame.image.load(floor_map_fname)
        self.floor_map_width = self.floor_map.get_width()
        self.floor_map_height = self.floor_map.get_height()
        self.gwin = pygame.display.set_mode((self.floor_map_width, self.floor_map_height))
        print("Floor_map size = {} x {}".format(self.floor_map_width, self.floor_map_height))
            # prepare grid from floor_map
        self.grid_size = grid_size
        self.floor_grid = self.init_floor_grid()
        self.grid = Grid(matrix = self.floor_grid)
        self.finder = AStarFinder(diagonal_movement = DiagonalMovement.always)
        #self.finder = AStarFinder()

    def init_floor_grid(self):
        floor_grid = []
        grid_size = self.grid_size
        floor_grid_width, floor_grid_height = self.floor_map_width//grid_size, self.floor_map_height//grid_size
        #print("floor_map_width = {} => floor_grid_width = {}".format(self.floor_map_width, floor_grid_width))
        #print("floor_map_height = {} => floor_grid_height = {}".format(self.floor_map_height, floor_grid_height))
        for r in range(floor_grid_height+1):
            floor_grid_row = []
            for c in range(floor_grid_width+1):
                floor_grid_row.append(1) # initial value 1 as free space
            floor_grid.append(floor_grid_row)
        print("len(floor_grid) = {}, len(floor_grid[0]) = {}".format(len(floor_grid), len(floor_grid[0])))
        #print("floor_grid = \n", floor_grid)    
        for r in range(self.floor_map_height):
            for c in range(self.floor_map_width):
                spot_color = self.floor_map.get_at((c, r))
                if spot_color == Colors.Black:
                    gr, gc = r//self.grid_size, c//grid_size
                    floor_grid[gr][gc] = 0 # 0 means obstacle

        # print floor_grid
        print("floor_grid ({} x {}) ".format(len(floor_grid), len(floor_grid[0])))
        """
        for r in range(len(floor_grid)):
            for c in range(len(floor_grid[0])):
                print("{:2d}".format(floor_grid[r][c]), end=' ')
            print()
        """
        return floor_grid
    
    def show_floor_grid(self):
        grid_size = self.grid_size
        for r in range(len(self.floor_grid)):
            for c in range(len(self.floor_grid[0])):
                x = c * grid_size - grid_size //2
                y = r * grid_size - grid_size //2
                grid_block = (x, y, grid_size, grid_size)
                if self.floor_grid[r][c] == 0:
                    pygame.draw.rect(self.gwin, Colors.Grey, grid_block)
                else:
                    pygame.draw.rect(self.gwin, Colors.White, grid_block)
        pygame.display.update()
    
    def find_path(self, start_gpos, end_gpos):
        self.floor_grid = self.init_floor_grid()
        self.grid = Grid(matrix = self.floor_grid)
        self.finder = AStarFinder(diagonal_movement = DiagonalMovement.always)
        start_gx, start_gy = start_gpos # (col, row)
        end_gx, end_gy = end_gpos # (col, row)
        start_node = self.grid.node(start_gx, start_gy)
        end_node = self.grid.node(end_gx, end_gy) # (col, row)
        path, runs = self.finder.find_path(start_node, end_node, self.grid)
        # show path on gwin
        if len(path) != 0:
            prev_pos = (path[0][0] * grid_size, path[0][1] * grid_size)
            for gpos in path:
                pos = (gpos[0] * grid_size, gpos[1] * grid_size)
                pygame.draw.line(self.gwin, path_colors[path_count % len(path_colors)], prev_pos, pos, 5)
                prev_pos = pos
        return path, runs

        
# --------------------------------
path_colors = Colors.Color_List
floor_map_fname = "floor_map0.png"
grid_size = 8
if __name__ == '__main__':
    pygame.init()
    PF = PathFinder(floor_map_fname, grid_size)
    pygame.display.set_caption("Path Finding on given Floor_map")
    pygame.mouse.set_cursor(*pygame.cursors.diamond)
    
    start_gx, start_gy = 16, 16 # coordinates on grid
    start_grid_pos = (start_gx, start_gy)
    end_gx, end_gy = 20, 5
    mark_size = grid_size
    
    # show floor_grid
    PF.show_floor_grid()
    start_x, start_y = start_gx * grid_size - grid_size //2, start_gy * grid_size - grid_size //2
    start_mark = (start_x, start_y, mark_size, mark_size) # pos_x, pos_y, width, height
    pygame.draw.rect(PF.gwin, Colors.Blue, start_mark)
    
    update_path_flag = False
    path_count = 0
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if pygame.mouse.get_focused():
                mouse_pos = pygame.mouse.get_pos() # returns (x, y)
                mouse_gx, mouse_gy = mouse_pos[0] // grid_size, mouse_pos[1] // grid_size
                if PF.floor_grid[mouse_gy][mouse_gx] == 1 and pygame.mouse.get_pressed() == (1, 0, 0):
                    end_gx, end_gy = mouse_pos[0] // grid_size, mouse_pos[1] // grid_size
                    end_grid_pos = (end_gx, end_gy )

                    print("{}-th end grid_pos = ({})".format(path_count, (end_gx, end_gy)))
                    end_x, end_y = end_gx * grid_size - grid_size //2, end_gy * grid_size - grid_size //2
                    end_mark = (end_x, end_y, mark_size, mark_size) # pos_x, pos_y, width, height
                    pygame.draw.rect(PF.gwin, path_colors[path_count % len(path_colors)], end_mark)
                    pygame.display.update()
                    update_path_flag = True
                    
                    path, runs = PF.find_path(start_grid_pos, end_grid_pos)
                    print("start_grid_pos = ({}), {}-th end_grid_pos = ({})".format(start_grid_pos, path_count, end_grid_pos))
                    print("path = ", path)
                    print("runs = ", runs)
                    if len(path) == 0:
                         print("Path not found !!")
                         continue
                    path_count += 1

                else:
                    continue
        pygame.display.update()
        if update_path_flag == False:
            time.sleep(0.1)
            continue

