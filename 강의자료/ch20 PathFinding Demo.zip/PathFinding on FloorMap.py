# RRT Path Finding on Floor Map

import numpy as np
from random import random
import math
import pygame
import Colors
import RTT_PathFinding as rtt_pf

# --------------------------------
if __name__ == '__main__':
    floor_map = pygame.image.load("floor_map1.png")
    floor_map_width = floor_map.get_width()
    floor_map_height = floor_map.get_height()
    print("Floor_map size = {} x {}".format(floor_map_width, floor_map_height))
    pygame.display.set_caption("RRT Path Finding on given Floor_map")
    RRT_surface = pygame.display.set_mode((floor_map_width, floor_map_height))
    RRT_surface.blit(floor_map, (0, 0))

    # Create a Graph
    start_pos = (70, 80)
    end_pos = (270, 170)
    mark_size = 10
    start_mark = (start_pos[0] - mark_size/2, start_pos[1] - mark_size/2, mark_size, mark_size) # pos_x, pos_y, width, height
    end_mark = (end_pos[0] - mark_size/2, end_pos[1] - mark_size/2, mark_size, mark_size) # pos_x, pos_y, width, height

    G = rtt_pf.Graph(start_pos, end_pos)
    floor_obstacles = []

    # insert obstacles into the Graph
    for y in range(floor_map_height):
        for x in range(floor_map_width):
            spot_color = floor_map.get_at((x, y))
            if spot_color == Colors.Color_Black:
                floor_obstacles.append((x, y))
    pygame.draw.circle(RRT_surface, Colors.Color_Red, start_pos, mark_size)
    pygame.draw.circle(RRT_surface, Colors.Color_Blue, end_pos, mark_size)
    #pygame.draw.rect(RRT_surface, Colors.Color_Red, start_mark)
    #pygame.draw.rect(RRT_surface, Colors.Color_Blue, end_mark)

    pygame.display.update()
    

    #obstacles = [(1., 1.), (2., 2.), (4., 4.)]
    n_iter = 400
    radius = 40
    stepSize = 20
    print("start_pos({}), end_pos({})".format(start_pos, end_pos))
    print("RRT_star with n_iter = {}, radius = {}, step_size = {}".format(n_iter, radius, stepSize))
    G = rtt_pf.RRT_star(RRT_surface, start_pos, end_pos, floor_obstacles, n_iter, radius, stepSize)
    #G = rtt_pf.RRT(RRT_surface, start_pos, end_pos, floor_obstacles, n_iter, radius, stepSize)

    show_RRT(RRT_surface, G)
    
    if G.success:
        print("Path found")
        path = dijkstra(G)
        print(path)
        prev_vrtx = start_pos
        for vrtx in path:
            pygame.draw.line(RRT_surface, Colors.Color_Red, prev_vrtx, vrtx, 2)
            prev_vrtx = vrtx
        pygame.display.update()
    else:
        print("Path finding failed")

    pygame.display.update()
    input("press any key to terminate")
    pygame.quit()

