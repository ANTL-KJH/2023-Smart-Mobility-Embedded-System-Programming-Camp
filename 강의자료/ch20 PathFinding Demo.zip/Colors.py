# Colors.py

import random

Black = (0, 0, 0)
Grey = (70, 70, 70)
Blue = (0, 0, 255)
Green = (0, 255, 0)
Red = (255, 0, 0)
White = (255, 255, 255)
Yellow = (255, 255, 0)
Light_Green = (144, 238, 144)
Cyan = (0, 255, 139)
Violet = (127, 0, 255)
YellowGreen = (154, 205, 50)
Tomato = (255, 99, 71)
Lime = (177, 221, 146)
Magenta = (208, 65, 126)
Brown = (128, 96, 77)
Maroon = (130, 0, 0)
Chocolate = (123, 63, 0)
ForestGreen = (1, 68, 33)

Color_List = [Red, Cyan, Violet, YellowGreen, Tomato, Lime, Magenta, Brown, Maroon, Chocolate, ForestGreen, Green, Blue]

