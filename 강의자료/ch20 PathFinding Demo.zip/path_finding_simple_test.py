# PathFinding with pathfinding module

from pathfinding.core.grid import Grid
from pathfinding.finder.a_star import AStarFinder
from pathfinding.core.diagonal_movement import DiagonalMovement

floor_map = [
    [1, 1, 1, 0, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 0, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 0, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 0, 1, 1, 0, 1, 1, 1],
    [1, 1, 1, 0, 1, 1, 0, 1, 1, 1],
    [1, 1, 1, 0, 1, 1, 0, 1, 1, 1],
    [1, 1, 1, 0, 1, 1, 0, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 0, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 0, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 0, 1, 1, 1]]

# create a grid, start and end node
grid = Grid(matrix = floor_map)
start_x, start_y = 0, 0
end_x, end_y = 9, 9
start = grid.node(start_x, start_y)
end = grid.node(end_x, end_y) # (col, row)

finder = AStarFinder(diagonal_movement = DiagonalMovement.always)

path, runs = finder.find_path(start, end, grid)

print("start = ({}, {}), end = ({}, {})".format(start_x, start_y, end_x, end_y))
print("path = ", path)
print("runs = ", runs)
